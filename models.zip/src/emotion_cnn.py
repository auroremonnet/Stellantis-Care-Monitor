import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

class EmotionCNNAnalyzer:
    """
    Analyseur d'émotion basé sur un ResNet18 fine-tuné.
    Optimisé pour RunPod (GPU CUDA).
    """

    def __init__(self, model_path="models/emotion_resnet18_affectnet.pt", device=None):
        # 1. DÉTECTION DU GPU (CRUCIAL POUR RUNPOD)
        # On définit le processeur cible avant de charger quoi que ce soit
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)
            
        print(f"[INFO] EmotionCNN: Configuration du device... Cible: {self.device}")
        
        if self.device.type == 'cuda':
            print(f"[INFO] GPU détecté: {torch.cuda.get_device_name(0)}")

        # 2. CHARGEMENT DU CHECKPOINT
        # On charge directement sur le GPU pour gagner du temps (map_location)
        try:
            checkpoint = torch.load(model_path, map_location=self.device)
        except FileNotFoundError:
            print(f"[ERREUR] Le fichier modèle est introuvable : {model_path}")
            raise

        # Récupération des classes
        self.classes = checkpoint["classes"]

        # 3. RECONSTRUCTION DU MODÈLE
        num_classes = len(self.classes)
        model = models.resnet18(weights=None) # Pas de poids ImageNet, on va charger les nôtres
        in_features = model.fc.in_features
        model.fc = torch.nn.Linear(in_features, num_classes)

        # Chargement des poids entraînés
        model.load_state_dict(checkpoint["state_dict"])
        
        # Envoi explicite sur le GPU (si pas déjà fait par le load)
        model.to(self.device)
        model.eval() # Mode évaluation (fige les poids)

        self.model = model
        print("[INFO] Modèle EmotionCNN chargé avec succès sur le GPU.")

        # Transformations d'entrée (Normalisation standard ImageNet)
        self.tf = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])

    def _map_emotion_to_confort(self, emo_label: str):
        """
        Regroupe les émotions en Confort / Neutre / Inconfort
        """
        emo = emo_label.lower()

        if emo in ["happy", "surprise"]:
            return "confort"
        elif emo in ["neutral"]:
            return "neutre"
        else:
            return "inconfort"

    def analyze_emotion(self, face_bgr: np.ndarray):
        """
        Analyse une image de visage (OpenCV BGR).
        """
        # BGR -> RGB -> PIL
        face_rgb = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(face_rgb)

        # Prétraitement
        # .to(self.device) est CRUCIAL ici : l'image doit rejoindre le modèle sur le GPU
        x = self.tf(pil_img).unsqueeze(0).to(self.device)

        # Inférence
        with torch.no_grad():
            logits = self.model(x)
            # On renvoie le résultat sur le CPU pour le traiter avec Numpy
            probs = F.softmax(logits, dim=1).cpu().numpy()[0]

        # Emotion dominante
        idx = int(np.argmax(probs))
        emo_label = self.classes[idx]
        emo_score = float(probs[idx])

        # Conversion en dictionnaire
        scores_dict = {
            cls: float(p) for cls, p in zip(self.classes, probs)
        }

        # Mapping confort
        confort_state = self._map_emotion_to_confort(emo_label)

        return emo_label, emo_score, confort_state, scores_dict